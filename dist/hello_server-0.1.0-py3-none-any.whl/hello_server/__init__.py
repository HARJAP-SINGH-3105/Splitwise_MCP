"""Hello Server - An MCP server built with Smithery."""

__version__ = "0.1.0"
